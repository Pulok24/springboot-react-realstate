**Spring Boot Project to develop a REST Interface for retrieval of Real Estate Data**

Run mongodb - mongod
Run Spring boot - mvn clean spring-boot:run
Run React app - npm install , npm start