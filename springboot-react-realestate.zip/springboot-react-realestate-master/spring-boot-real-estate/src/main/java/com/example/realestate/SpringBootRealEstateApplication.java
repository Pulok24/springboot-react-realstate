package com.example.realestate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRealEstateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRealEstateApplication.class, args);
	}

}
