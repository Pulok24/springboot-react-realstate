package com.example.realestate.repository;

import com.example.realestate.model.RealEstateCount;

import java.util.List;

public interface RealEstateRepositoryCustom {

    List<RealEstateCount> getRealEstateCount();
}
